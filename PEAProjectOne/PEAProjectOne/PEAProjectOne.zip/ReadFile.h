#pragma once
class ReadFile
{
public:
	ReadFile();

	int **openFile(int &cities);

	~ReadFile();
};

